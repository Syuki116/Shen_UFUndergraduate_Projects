Name: Xinyu Shen
Section: 11969
UFL email: shenxinyu@ufl.edu
System: MacOS (M chip)
Compiler: c++
SFML version: 2.6.1
IDE: CLion
Other notes: None