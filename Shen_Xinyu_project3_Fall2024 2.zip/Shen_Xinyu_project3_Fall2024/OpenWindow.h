//
// Created by Xinyu Shen on 12/1/24.
//

#ifndef OPENWINDOW_H
#define OPENWINDOW_H
#include "Functions.h"


sf::Text Text_generator(const sf::Font &font,
                        const std::string &text, int size,
                        sf::Color color, sf::Uint32 style = sf::Text::Regular) {
    sf::Text sfText;
    sfText.setFont(font);
    sfText.setString(text);
    sfText.setCharacterSize(size);
    sfText.setFillColor(color);
    sfText.setStyle(style);
    return sfText;
}
// Function to capitalize a name
std::string Capitalize_name(const std::string &name) {
    if (name.empty()) return "";
    std::string formattedName = name;
    formattedName[0] = std::toupper(formattedName[0]);
    for (int i = 1; i < formattedName.length(); ++i) {
        formattedName[i] = std::tolower(formattedName[i]);
    }
    return formattedName;
}

void loadTextures(Manage_texture& M_t) {
    M_t.loadTexture("tile_hidden", "files/images/tile_hidden.png");
    M_t.loadTexture("tile_revealed", "files/images/tile_revealed.png");
    M_t.loadTexture("mine", "files/images/mine.png");
    M_t.loadTexture("flag", "files/images/flag.png");
    M_t.loadTexture("face_happy", "files/images/face_happy.png");
    M_t.loadTexture("face_lose", "files/images/face_lose.png");
    M_t.loadTexture("face_win", "files/images/face_win.png");
    M_t.loadTexture("pause", "files/images/pause.png");
    M_t.loadTexture("debug", "files/images/debug.png");
    M_t.loadTexture("leaderboard", "files/images/leaderboard.png");
    M_t.loadTexture("play", "files/images/play.png");

    for (int i = 1; i <= 8; ++i) {
        M_t.loadTexture("number_" + std::to_string(i), "files/images/number_" + std::to_string(i) + ".png");
    }
}



std::string openWelcomeWindow(sf::Font& font, int welcome_window_width, int welcome_window_height) {
    sf::RenderWindow welcome_window(sf::VideoMode(welcome_window_width, welcome_window_height),
                                    "Welcome to Minesweeper", sf::Style::Close);
    sf::Text title = Text_generator(font, "WELCOME TO MINESWEEPER!", 24, sf::Color::White,
        sf::Text::Bold | sf::Text::Underlined);
    setText(title, welcome_window_width / 2.f, welcome_window_height / 2.f - 150);

    sf::Text name_prompt = Text_generator(font, "Enter your name:", 20, sf::Color::White, sf::Text::Bold);
    setText(name_prompt, welcome_window_width / 2.f, welcome_window_height / 2.f - 75);

    sf::Text entered_name = Text_generator(font, "", 18, sf::Color::Yellow);
    std::string inputName;

    while (welcome_window.isOpen()) {
        sf::Event event;
        while (welcome_window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                welcome_window.close();
            } else if (event.type == sf::Event::TextEntered) {
                if (event.text.unicode < 128) {
                    char charTyped = static_cast<char>(event.text.unicode);
                    const std::string valid_characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    if (inputName.length() < 10 && valid_characters.find(charTyped) != std::string::npos) {
                        inputName += charTyped;
                        inputName = Capitalize_name(inputName);
                    }
                }
            } else if (event.type == sf::Event::KeyPressed) {
                if (!inputName.empty() && event.key.code == sf::Keyboard::BackSpace) {
                    inputName.erase(inputName.size() - 1);
                } else if (!inputName.empty() && event.key.code == sf::Keyboard::Enter) {
                    welcome_window.close();
                }
            }
        }

        welcome_window.clear(sf::Color::Blue);
        welcome_window.draw(title);
        welcome_window.draw(name_prompt);
        entered_name.setString(inputName + '|');
        setText(entered_name, (float)welcome_window_width / 2, (float)welcome_window_height / 2 - 45);
        welcome_window.draw(entered_name);
        welcome_window.display();
    }

    return inputName;
}

void openGameWindow(sf::Font& font, Manage_texture& M_t,
                    int game_width, int game_height,
                    int leaderboard_window_width, int leaderboard_window_height,
                    int row_num, int col_num, int mine_num, const std::string& inputName) {
    sf::RenderWindow game(sf::VideoMode(game_width, game_height), "Minesweeper", sf::Style::Close);
    game_board gameboard(row_num, col_num, mine_num, M_t);

    while (game.isOpen()) {
        gameboard.timer.overwrite_time();

        sf::Event event;
        while (game.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                game.close();
            }

            else if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(game);

                    int x = mousePos.x / TILE_SIZE; // Column
                    int y = mousePos.y / TILE_SIZE; // Row

                    if (x >= 0 && x < col_num && y >= 0 && y < row_num) {
                        gameboard.tiles[y][x].reveal_some(M_t);

                        if (gameboard.checking_fail()) {
                            gameboard.is_paused = true;
                            gameboard.is_failure = true;
                            for (int a = 0; a < gameboard.row_count; ++a) {
                                for (int b = 0; b < gameboard.col_count; ++b) {
                                    gameboard.tiles[a][b].reveal_every_tile(M_t);
                                }
                            }
                        }
                    } else if (gameboard.face_click.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        if (!gameboard.leaderboard_open) {
                            gameboard.clean_board(row_num, col_num, mine_num, M_t);
                            gameboard.timer = Timer_class(); // Reset the timer

                        }
                    } else if (gameboard.debug_click.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        if (!gameboard.checking_win() && !gameboard.checking_fail() && !gameboard.is_paused) {
                            gameboard.debugging = !gameboard.debugging;

                            for (int a = 0; a < gameboard.row_count; ++a) {
                                for (int b = 0; b < gameboard.col_count; ++b) {
                                    if (gameboard.debugging) {
                                        gameboard.tiles[a][b].reveal_mine(M_t);
                                    } else {
                                        gameboard.tiles[a][b].cover_mine(M_t);
                                    }
                                }
                            }
                        }
                    } else if (gameboard.pause_click.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        if (!gameboard.checking_win() && !gameboard.checking_fail() && !gameboard.leaderboard_open) {
                            gameboard.is_paused = !gameboard.is_paused;

                            if (gameboard.is_paused) {
                                gameboard.pause_click.setTexture(M_t.getTexture("play"));
                            } else {
                                gameboard.pause_click.setTexture(M_t.getTexture("pause"));
                            }

                            gameboard.timer.Pause_situation();
                        }

                    } else if (gameboard.leaderboard_click.getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                        // Store the current game state
                        game_board snapshot_gameboard = gameboard;

                        // Create an empty revealed gameboard
                        game_board empty_revealed_gameboard = gameboard;

                        //Reveal all tiles
                        for (int y = 0; y < gameboard.row_count; ++y) {
                            for (int x = 0; x < gameboard.col_count; ++x) {
                                gameboard.tiles[y][x].tile_is_revealed = true; // Reveal all tiles
                            }
                        }

                        bool is_current_paused = gameboard.is_paused;

                        sf::RenderWindow leaderboard(sf::VideoMode(leaderboard_window_width, leaderboard_window_height),
                            "Leaderboard", sf::Style::Close);

                        sf::Text leaderboard_text = Text_generator(font, "LEADERBOARD", 20, sf::Color::White,
                            sf::Text::Bold | sf::Text::Underlined);
                        setText(leaderboard_text, leaderboard_window_width / 2.f,
                            leaderboard_window_height / 2.f - 120);

                        sf::Text ranking = Text_generator(font, read_in_leaderboard(), 18, sf::Color::White,
                            sf::Text::Bold);
                        setText(ranking, leaderboard_window_width / 2.f, leaderboard_window_height / 2.f + 20);

                        while (leaderboard.isOpen()) {
                            sf::Event leaderboard_event;
                            while (leaderboard.pollEvent(leaderboard_event)) {
                                if (leaderboard_event.type == sf::Event::Closed) {
                                    leaderboard.close();
                                    gameboard.is_paused = is_current_paused;  // Restore pause state
                                    gameboard = snapshot_gameboard;          // Restore the original game state
                                }
                            }


                            leaderboard.clear(sf::Color::Blue);
                            leaderboard.draw(leaderboard_text);
                            leaderboard.draw(ranking);
                            leaderboard.display();

                            game.clear(sf::Color::White);
                            gameboard.draw(game);
                            game.display();
                        }
                    }
                } else if (event.mouseButton.button == sf::Mouse::Right) {
                    if (!gameboard.checking_fail() && !gameboard.checking_win() && !gameboard.is_paused) {
                        sf::Vector2i mousePos = sf::Mouse::getPosition(game);
                        int x = mousePos.x / TILE_SIZE;
                        int y = mousePos.y / TILE_SIZE;

                        if (x >= 0 && x < col_num && y >= 0 && y < row_num) {
                            if (!gameboard.tiles[y][x].tile_is_revealed) {
                                gameboard.tiles[y][x].flag_situation();
                            }
                        }
                    }
                }
            }
        }

        if (gameboard.checking_fail()) {
            gameboard.is_paused = true;
            gameboard.timer.isPaused = true;
        }

        else if (!gameboard.is_victory && gameboard.checking_win()) {
            // Mark the game as won
            gameboard.is_victory = true;
            // Flag all mines without revealing them
            for (int y = 0; y < gameboard.row_count; ++y) {
                for (int x = 0; x < gameboard.col_count; ++x) {
                    if (gameboard.tiles[y][x].mine_tile) {
                        gameboard.tiles[y][x].is_flagged = true;
                        gameboard.tiles[y][x].tile_is_revealed = false;
                    }
                }
            }
            gameboard.face_click.setTexture(M_t.getTexture("face_win"));
            game.clear(sf::Color::White);
            gameboard.draw(game);
            game.display();

            // Pause briefly to let the player see the flags and face change
            //sf::sleep(sf::seconds(1));
            int game_time = gameboard.timer.minutes * 60 + gameboard.timer.seconds;
            gameboard.is_paused = true;
            gameboard.timer.isPaused = true;
            overwrite_leaderboard(game_time, inputName);
            std::string updated_leaderboard = read_in_leaderboard();
            sf::RenderWindow leaderboard(sf::VideoMode(leaderboard_window_width, leaderboard_window_height), "Leaderboard", sf::Style::Close);

            sf::Text leaderboard_text = Text_generator(font, "LEADERBOARD", 20, sf::Color::White, sf::Text::Bold | sf::Text::Underlined);
            setText(leaderboard_text, leaderboard_window_width / 2.f, leaderboard_window_height / 2.f - 120);

            sf::Text ranking = Text_generator(font, updated_leaderboard, 18, sf::Color::White, sf::Text::Bold);
            setText(ranking, leaderboard_window_width / 2.f, leaderboard_window_height / 2.f + 20);

            while (leaderboard.isOpen()) {
                sf::Event leaderboard_event;
                while (leaderboard.pollEvent(leaderboard_event)) {
                    if (leaderboard_event.type == sf::Event::Closed) {
                        leaderboard.close();
                    }
                }

                leaderboard.clear(sf::Color::Blue);
                leaderboard.draw(leaderboard_text);
                leaderboard.draw(ranking);
                leaderboard.display();
            }
        }

        game.clear(sf::Color::White);
        gameboard.draw(game);
        game.display();
    }
}




#endif //OPENWINDOW_H
