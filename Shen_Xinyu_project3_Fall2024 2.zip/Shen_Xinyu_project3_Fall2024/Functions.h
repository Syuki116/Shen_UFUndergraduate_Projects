//
// Created by Xinyu Shen on 12/1/24.
//

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
#include <random>
using namespace std;

const int TILE_SIZE = 32;

class Manage_texture {
private:
    std::unordered_map<std::string, sf::Texture> textures;
public:
    bool loadTexture(const std::string& key, const std::string& filePath) {
        sf::Texture texture;
        if (!texture.loadFromFile(filePath)) {
            std::cerr << "Error: texture load fail " << filePath << std::endl;
            return false;
        }
        textures[key] = std::move(texture);
        return true;
    }
    // Retrieve a texture by its key
    const sf::Texture& getTexture(const std::string& key) const {
        try {
            return textures.at(key);
        } catch (const std::out_of_range&) {
            std::cerr << "Error: Out of range. Texture not found for this key:" << key << std::endl;
            throw;
        }
    }
    // Remove a texture by its key (optional)
    void removeTexture(const std::string& key) {
        textures.erase(key);
    }

    // Clear all loaded textures
    void clear() {
        textures.clear();
    }
};



//Given setText function to align text
void setText(sf::Text& text, float x, float y) {
    sf::FloatRect textRect = text.getLocalBounds();
    text.setOrigin(textRect.left + textRect.width / 2.0f, textRect.top + textRect.height / 2.0f);
    text.setPosition(sf::Vector2f(x, y));
}



// TILE class
struct Tile_class {
    sf::Sprite revealed_tile;
    sf::Sprite hint;
    sf::Sprite hidden_tile;
    sf::Sprite flag_shown;

    bool mine_tile = false;
    bool tile_is_revealed = false;
    bool is_flagged = false;
    bool cover = false;
    std::vector<Tile_class*> tiles_around;

    // Default constructor
    Tile_class() = default;

    // Constructor with Manage_texture
    Tile_class(Manage_texture& M_t) {
        setTextures(M_t);
    }

    // Pass a Manage_texture instance to set textures
    void setTextures(Manage_texture& M_t) {
        hidden_tile.setTexture(M_t.getTexture("tile_hidden"));
        revealed_tile.setTexture(M_t.getTexture("tile_revealed"));
        flag_shown.setTexture(M_t.getTexture("flag"));
    }

    void reveal_some(Manage_texture& M_t) {
        if (!is_flagged) {
            tile_is_revealed = true;
            if (mine_tile) {
                hint.setTexture(M_t.getTexture("mine"));
            } else {
                int count = count_mines_around();
                if (count > 0 && count <= 8) {
                    hint.setTexture(M_t.getTexture("number_" + std::to_string(count)));
                } else {
                    // Recursively reveal neighboring tiles
                    for (Tile_class* neighbor : tiles_around) {
                        if (!neighbor->tile_is_revealed) {
                            neighbor->reveal_some(M_t);
                        }
                    }
                }
            }
        }
    }

    void reveal_every_tile(Manage_texture& M_t) {
        tile_is_revealed = true;
        if (mine_tile) {
            hint.setTexture(M_t.getTexture("mine"));
        } else {
            int count = count_mines_around();
            if (count > 0 && count <= 8) {
                hint.setTexture(M_t.getTexture("number_" + std::to_string(count)));
            }
        }
    }

    void cover_mine(Manage_texture& M_t) {
        if (mine_tile) {
            tile_is_revealed = false;
            // Reset the hint texture for mines when covering them
            hint.setTexture(M_t.getTexture("tile_hidden"));
        }
    }

    void reveal_flag_only(Manage_texture& M_t) {
        if (is_flagged) {
            tile_is_revealed = true; // Reveal only flagged tiles
            hint.setTexture(M_t.getTexture("flag")); // Ensure the flag texture is displayed
        }
    }

    void reveal_mine(Manage_texture& M_t) {
        if (mine_tile) {
            tile_is_revealed = true;
            hint.setTexture(M_t.getTexture("mine"));
        }
    }

    void draw(sf::RenderWindow& window) {
        if (!cover) {
            window.draw(hidden_tile); // Draw hidden tile
            if (tile_is_revealed) {
                window.draw(revealed_tile); // Draw revealed tile
                window.draw(hint);         // Draw hint (number/mine)
            }
            if (is_flagged) {
                window.draw(flag_shown); // Draw flag if flagged
            }
        } else {
            window.draw(revealed_tile); // Draw revealed tile when uncovered
        }
    }

    void flag_situation() {
        is_flagged = !is_flagged;
    }

    int count_mines_around() {
        int count = 0;
        for (Tile_class* neighbor : tiles_around) {
            if (neighbor->mine_tile) {
                count++;
            }
        }
        return count;
    }
};




///TIMER
struct Timer_class{
    sf::Texture digitTextures[10];
    sf::Sprite digits[4];
    sf::Clock Clock_func;
    sf::Time paused_time;
    sf::Time game_time;
    bool isPaused = false;
    int minutes = 0;
    int seconds = 0;

    Timer_class(){}

    void Pause_situation() {
        if (isPaused) {
            Clock_func.restart();
            isPaused = false;
        }
        else {
            // Pause the timer
            paused_time += Clock_func.getElapsedTime();
            isPaused = true;
        }
    }

    void overwrite_time() {
        if (!isPaused){
            game_time = Clock_func.getElapsedTime() + paused_time;
            minutes = int(game_time.asSeconds()) / 60;
            seconds = int(game_time.asSeconds()) % 60;
        }
    }

    void draw(sf::RenderWindow& window){
        for (int i = 0; i < 10; ++i) {
            digitTextures[i].loadFromFile("files/images/digits.png",
                sf::IntRect (21*i, 0, 21,32));
        }
        digits[0].setTexture(digitTextures[minutes / 10]);
        digits[1].setTexture(digitTextures[minutes % 10]);
        digits[2].setTexture(digitTextures[seconds / 10]);
        digits[3].setTexture(digitTextures[seconds % 10]);
        window.draw(digits[0]);
        window.draw(digits[1]);
        window.draw(digits[2]);
        window.draw(digits[3]);
    }


};


/// counter
struct Counter{
    sf::Texture digitTextures[11];
    sf::Sprite digits[3];

    Counter(){

    }


    void draw(sf::RenderWindow& window, int count){
        for (int i = 0; i < 11; ++i) {
            digitTextures[i].loadFromFile("files/images/digits.png",
                sf::IntRect (21*i, 0, 21,32));
        }
        int tens_place = abs(count) / 10;
        int ones_place = abs(count) % 10;
        digits[0].setTexture(digitTextures[10]);
        digits[1].setTexture(digitTextures[tens_place]);
        digits[2].setTexture(digitTextures[ones_place]);
        window.draw(digits[1]);
        window.draw(digits[2]);
        if (count < 0) {
            window.draw(digits[0]);
        }
    }
};


/// board class
struct game_board {
    vector<vector<Tile_class>> tiles;
    Counter mine_counter;
    Timer_class timer;
    sf::Clock Clock_func;
    sf::Time elapsed = Clock_func.getElapsedTime();
    int row_count;
    int col_count;
    int number_of_mines;
    bool is_paused = false;
    bool debugging = false;
    bool leaderboard_open = false;
    bool is_failure = false;
    bool is_victory = false;
    sf::Sprite face_click;
    sf::Sprite pause_click;
    sf::Sprite debug_click;
    sf::Sprite leaderboard_click;
    Manage_texture& M_t;

    void board_revealall(Manage_texture& M_t) {
        for (int y = 0; y < row_count; ++y) {
            for (int x = 0; x < col_count; ++x) {
                tiles[y][x].reveal_every_tile(M_t);
            }
        }
    }

    // Constructor
    game_board(int row_count, int col_count, int number_of_mines, Manage_texture& M_t)
        : row_count(row_count), col_count(col_count), number_of_mines(number_of_mines), M_t(M_t) {

        tiles.resize(row_count, vector<Tile_class>(col_count));

        for (int y = 0; y < row_count; ++y) {
            for (int x = 0; x < col_count; ++x) {
                tiles[y][x] = Tile_class(M_t);
            }
        }

        for (int y = 0; y < row_count; y++) {
            for (int x = 0; x < col_count; x++) {
                vector<Tile_class*> tiles_around;

                for (int i = -1; i <= 1; i++) {
                    for (int j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue; // Skip the tile itself

                        int ny = y + i;
                        int nx = x + j;
                        if (ny >= 0 && ny < row_count && nx >= 0 && nx < col_count) {
                            tiles_around.push_back(&tiles[ny][nx]);
                        }
                    }
                }

                tiles[y][x].tiles_around = tiles_around;
            }
        }
        random_mine_placing(number_of_mines);

        // Load button textures using TextureManager
        face_click.setTexture(M_t.getTexture("face_happy"));
        pause_click.setTexture(M_t.getTexture("pause"));
        debug_click.setTexture(M_t.getTexture("debug"));
        leaderboard_click.setTexture(M_t.getTexture("leaderboard"));
    }


    // Copy Assignment Operator
    game_board& operator=(const game_board& other) {
        if (this != &other) { // Avoid self-assignment
            row_count = other.row_count;
            col_count = other.col_count;
            number_of_mines = other.number_of_mines;
            is_paused = other.is_paused;
            debugging = other.debugging;
            leaderboard_open = other.leaderboard_open;
            is_failure = other.is_failure;
            is_victory = other.is_victory;

            // Deep copy tiles
            tiles.clear();
            tiles.resize(row_count, std::vector<Tile_class>(col_count));
            for (int y = 0; y < row_count; ++y) {
                for (int x = 0; x < col_count; ++x) {
                    tiles[y][x] = other.tiles[y][x];
                }
            }

            timer = other.timer;
            M_t = other.M_t;
            face_click = other.face_click;
            pause_click = other.pause_click;
            debug_click = other.debug_click;
            leaderboard_click = other.leaderboard_click;
        }
        return *this;
    }


    void random_mine_placing(int func_num_mine) {
        std::vector<std::pair<int, int>> positions;
        for (int row = 0; row < row_count; ++row) {
            for (int col = 0; col < col_count; ++col) {
                positions.emplace_back(row, col);
            }
        }
        std::random_device rd;
        std::mt19937 gen(rd());
        std::shuffle(positions.begin(), positions.end(), gen);
        for (int i = 0; i < func_num_mine && i < positions.size(); ++i) {
            int row = positions[i].first;
            int col = positions[i].second;
            tiles[row][col].mine_tile = true;
        }
    }



    // Add clean_board method inside the class definition
    void clean_board(int row_count, int col_count, int number_of_mines, Manage_texture& M_t) {
        this->row_count = row_count;
        this->col_count = col_count;
        this->number_of_mines = number_of_mines;
        // Clear and reinitialize tiles
        tiles.clear();
        tiles.resize(row_count, std::vector<Tile_class>(col_count, Tile_class(M_t)));

        // Reassign tiles_around
        for (int y = 0; y < row_count; y++) {
            for (int x = 0; x < col_count; x++) {
                std::vector<Tile_class*> tiles_around;

                for (int i = -1; i <= 1; i++) {
                    for (int j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        int ny = y + i;
                        int nx = x + j;
                        if (ny >= 0 && ny < row_count && nx >= 0 && nx < col_count) {
                            tiles_around.push_back(&tiles[ny][nx]);
                        }
                    }
                }

                tiles[y][x].tiles_around = tiles_around;
            }
        }

        // Reset other properties
        is_paused = false;
        debugging = false;
        leaderboard_open = false;
        is_failure = false;
        is_victory = false;

        // Reinitialize buttons with textures
        face_click.setTexture(M_t.getTexture("face_happy"));
        pause_click.setTexture(M_t.getTexture("pause"));
        debug_click.setTexture(M_t.getTexture("debug"));
        leaderboard_click.setTexture(M_t.getTexture("leaderboard"));

        // Place mines
        random_mine_placing(number_of_mines);
    }

    void draw(sf::RenderWindow& window) {
        for (int y = 0; y < row_count; y++) {
            for (int x = 0; x < col_count; x++) {
                // Position each tile sprite based on its location in the grid
                tiles[y][x].hidden_tile.setPosition(x * 32, y * 32);
                tiles[y][x].revealed_tile.setPosition(x * 32, y * 32);
                tiles[y][x].hint.setPosition(x * 32, y * 32);
                tiles[y][x].flag_shown.setPosition(x * 32, y * 32);
                if (is_paused && !checking_win() && !checking_fail()) {
                    tiles[y][x].cover = true;
                } else {
                    tiles[y][x].cover = false;
                }
                tiles[y][x].draw(window);
            }
        }

        // Update status button texture
        if (is_failure) {
            face_click.setTexture(M_t.getTexture("face_lose"));
        } else if (is_victory) {
            face_click.setTexture(M_t.getTexture("face_win"));
        } else {
            face_click.setTexture(M_t.getTexture("face_happy"));
        }
        face_click.setPosition(col_count / 2 * 32 - 32, 32 * (row_count + 0.5));
        window.draw(face_click);
        pause_click.setPosition(col_count * 32 - 240, 32 * (row_count + 0.5));
        window.draw(pause_click);
        debug_click.setPosition(col_count * 32 - 304, 32 * (row_count + 0.5));
        window.draw(debug_click);
        leaderboard_click.setPosition(col_count * 32 - 176, 32 * (row_count + 0.5));
        window.draw(leaderboard_click);

        // Draw counter
        mine_counter.digits[0].setPosition(12, 32 * (row_count + 0.5) + 16);
        mine_counter.digits[1].setPosition(33, 32 * (row_count + 0.5) + 16);
        mine_counter.digits[2].setPosition(54, 32 * (row_count + 0.5) + 16);
        mine_counter.draw(window, func_num_mine());

        // Draw Timer
        timer.digits[0].setPosition(col_count * 32 - 97, 32 * (row_count + 0.5) + 16);
        timer.digits[1].setPosition(col_count * 32 - 76, 32 * (row_count + 0.5) + 16);
        timer.digits[2].setPosition(col_count * 32 - 54, 32 * (row_count + 0.5) + 16);
        timer.digits[3].setPosition(col_count * 32 - 33, 32 * (row_count + 0.5) + 16);
        timer.draw(window);
    }

    bool checking_fail() {
        if (debugging) {
            return false;
        }
        for (const auto& row : tiles) {
            for (const auto& tile : row) {
                if (tile.tile_is_revealed && tile.mine_tile) {
                    return true;
                }
            }
        }
        return false;
    }



    bool checking_win() {
        if (is_failure) {
            return false;
        }

        bool all_mines_flagged = true;
        bool all_safe_revealed = true;
        for (int y = 0; y < row_count; ++y) {
            for (int x = 0; x < col_count; ++x) {
                if (tiles[y][x].mine_tile) {
                    if (!tiles[y][x].is_flagged) {
                        all_mines_flagged = false;
                    }
                } else {
                    if (!tiles[y][x].tile_is_revealed) {
                        all_safe_revealed = false;
                    }
                }
            }
        }
        if (all_mines_flagged || all_safe_revealed) {
            is_victory = true;
            return true;
        }

        return false;
    }


    int func_num_mine() {
        int flagged_count = 0;
        for (const auto& row : tiles) {
            for (const auto& tile : row) {
                if (tile.is_flagged) {
                    flagged_count++;
                }
            }
        }
        return number_of_mines - flagged_count;
    }

};




string read_in_leaderboard() {
    ifstream file("files/leaderboard.txt");
    string line = "";
    string shown_data = "";
    vector<pair<string, string>> time_name_pair;

    // Read the file line by line
    while (getline(file, line)) {
        int comma_spot = line.find(',');
        if (comma_spot < line.size()) {  // valid index < string.size()
            string time = line.substr(0, comma_spot);
            string name = line.substr(comma_spot + 1);
            time_name_pair.push_back(std::make_pair(time, name));
        }
    }

    int start = 1;
    for (int i = 0; i < time_name_pair.size(); ++i) {
        const auto& pair = time_name_pair[i];
        shown_data += to_string(start++) + ".\t" + pair.first + "\t" + pair.second;
        if (i != time_name_pair.size() - 1) {
            shown_data += "\n\n";
        }
    }
    return shown_data;
}


// timer
int seconds_conversion(const string& time) {
    int colon_position = time.find(':');
    if (colon_position != string::npos) {
        string minutes = time.substr(0, colon_position);
        string seconds = time.substr(colon_position + 1);
        try {
            int min_count = stoi(minutes);
            int sec_count = stoi(seconds);
            return min_count * 60 + sec_count;
        } catch (const invalid_argument&) {
            return -1;
        } catch (const out_of_range&) {
            return -1;
        }
    }
    return -1;
}

string time_conversion(int totalseconds) {
    int minutes = totalseconds / 60;
    int seconds = totalseconds % 60;
    string time;
    if (minutes < 10) {
        time += "0";
    }
    time += to_string(minutes);
    time += ":";
    if (seconds < 10) {
        time += "0";
    }
    time += to_string(seconds);
    return time;
}


void overwrite_leaderboard(int game_time, string player_name) {

    ifstream file;
    string line;

    vector<string> store_score;
    vector<string> store_time;
    vector<string> store_playerName;

    file.open("files/leaderboard.txt");
    if (!file) {
        throw runtime_error("Leaderboard file failed to open.");
    }
    while (getline(file, line)) {
        stringstream ss(line);
        while (getline(ss, line, ',')) {
            store_score.push_back(line);
        }
    }
    for (int i = 0; i < store_score.size(); i = i + 2) {
        store_time.push_back(store_score[i]);
        store_playerName.push_back(store_score[i + 1]);
    }

    if (game_time < seconds_conversion(store_time[4])) {
        int position = 4;
        for (int i = 0; i < 4; ++i) {
            if (game_time < seconds_conversion(store_time[i])) {
                position = i;
                break;
            }
        }
        store_time.insert(begin(store_time) + position, time_conversion(game_time));
        store_playerName.insert(begin(store_playerName) + position, player_name);
        store_time.pop_back();
        store_playerName.pop_back();
    }
    file.close();


    int min_time_index = 0;
    int min_time = seconds_conversion(store_time[0]);
    for (int i = 1; i < store_time.size(); i++) {
        int current_time = seconds_conversion(store_time[i]);
        if (current_time < min_time) {
            min_time = current_time;
            min_time_index = i;
        }
    }


    for (int i = 0; i < store_playerName.size(); i++) {
        int asterisk_pos = store_playerName[i].find('*');
        if (asterisk_pos != string::npos) {
            store_playerName[i].erase(asterisk_pos, 1); // Remove any existing asterisks
        }
    }
    store_playerName[min_time_index] += '*';



    // write new leaderboard
    ofstream new_leaderboard("files/leaderboard.txt", ios::out);
    for (int i = 0; i < store_time.size(); i++){
        new_leaderboard << store_time[i] << "," << store_playerName[i] << "\n";
    }
    // Close the file
    new_leaderboard.close();
}






#endif //FUNCTIONS_H
