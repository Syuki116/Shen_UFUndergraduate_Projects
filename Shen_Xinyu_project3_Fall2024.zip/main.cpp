#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
#include <fstream>
#include <sstream>
#include "Functions.h"
#include "OpenWindow.h"

using namespace std;

const std::string configFilePath = "files/config.cfg";
int col_num = 0, row_num = 0, mine_num = 0;



// Function to parse the configusration file
bool parse_config(const std::string &configFilePath, int &colCount, int &rowCount, int &mineCount) {
    std::ifstream configFile(configFilePath);
    configFile >> colCount >> rowCount >> mineCount;
    return true;
}




int main() {
    if (!parse_config(configFilePath, col_num, row_num, mine_num)) {
        std::cerr << "Error: Failed to open configuration file.\n";
        return -1;
    }

    sf::Font font;
    if (!font.loadFromFile("files/font.ttf")) {
        std::cerr << "Error loading font.\n";
        return -1;
    }

    int welcome_window_width = col_num * TILE_SIZE;
    int welcome_window_height = row_num * TILE_SIZE + 100;
    int game_window_width = col_num * TILE_SIZE;
    int game_window_height = row_num * TILE_SIZE + 100;
    int leaderboard_window_width = col_num * 16;
    int leaderboard_window_height = row_num * 16 + 50;

    Manage_texture M_t;
    loadTextures(M_t);

    std::string inputName = openWelcomeWindow(font, welcome_window_width, welcome_window_height);

    if (!inputName.empty()) {
        openGameWindow(font, M_t, game_window_width, game_window_height,
                        leaderboard_window_width, leaderboard_window_height,
                        row_num, col_num, mine_num,inputName);
    }

    return 0;
}


