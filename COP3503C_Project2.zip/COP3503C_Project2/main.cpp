#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

// Define Header struct
struct Header {
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
};

//Define Pixel struct
struct Pixel {
    unsigned char BLUE;
    unsigned char GREEN;
    unsigned char RED;
};

// Define Image struct
struct Image {
    Header header;
    vector <Pixel> pixelData;
};

// Reading TGA
Image ReadTGA(const string& path) {
    ifstream file(path, ios::binary);
    Image image;

    if (!file.is_open()) {
        cerr << "Error: Input file" << path << "not found." << endl;
        return image;
    }

    Header header;
    // Read each header element individually
    file.read(reinterpret_cast<char*>(&header.idLength), sizeof(header.idLength));
    file.read(reinterpret_cast<char*>(&header.colorMapType), sizeof(header.colorMapType));
    file.read(reinterpret_cast<char*>(&header.dataTypeCode), sizeof(header.dataTypeCode));
    file.read(reinterpret_cast<char*>(&header.colorMapOrigin), sizeof(header.colorMapOrigin));
    file.read(reinterpret_cast<char*>(&header.colorMapLength), sizeof(header.colorMapLength));
    file.read(reinterpret_cast<char*>(&header.colorMapDepth), sizeof(header.colorMapDepth));
    file.read(reinterpret_cast<char*>(&header.xOrigin), sizeof(header.xOrigin));
    file.read(reinterpret_cast<char*>(&header.yOrigin), sizeof(header.yOrigin));
    file.read(reinterpret_cast<char*>(&header.width), sizeof(header.width));
    file.read(reinterpret_cast<char*>(&header.height), sizeof(header.height));
    file.read(reinterpret_cast<char*>(&header.bitsPerPixel), sizeof(header.bitsPerPixel));
    file.read(reinterpret_cast<char*>(&header.imageDescriptor), sizeof(header.imageDescriptor));

    image.header = header;

    // Check if width and height are valid
    if (header.width <= 0 || header.height <= 0){
        cerr << "Error: Invalid image dimensions." << endl;
        return image;
    }

    // Read pixel data
    int pixelCount = header.width * header.height;
    for (int i = 0; i< pixelCount; i++) {
        Pixel pixel;
        file.read(reinterpret_cast<char*>(&pixel.BLUE), sizeof(pixel.BLUE));
        file.read(reinterpret_cast<char*>(&pixel.GREEN), sizeof(pixel.GREEN));
        file.read(reinterpret_cast<char*>(&pixel.RED), sizeof(pixel.RED));

        image.pixelData.push_back(pixel);
    }
    file.close();

    return image;
}

void WriteFile(Image& image, const string& outputPath) {
    ofstream outputFile(outputPath, ios::binary);
    if (!outputFile.is_open()) {
        cout << "Failed to open output file" << outputPath << endl;
        return;
    }

    // Write header
    outputFile.write(reinterpret_cast<char*>(&image.header.idLength), sizeof(image.header.idLength));
    outputFile.write(reinterpret_cast<char*>(&image.header.colorMapType), sizeof(image.header.colorMapType));
    outputFile.write(reinterpret_cast<char*>(&image.header.dataTypeCode), sizeof(image.header.dataTypeCode));
    outputFile.write(reinterpret_cast<char*>(&image.header.colorMapOrigin), sizeof(image.header.colorMapOrigin));
    outputFile.write(reinterpret_cast<char*>(&image.header.colorMapLength), sizeof(image.header.colorMapLength));
    outputFile.write(reinterpret_cast<char*>(&image.header.colorMapDepth), sizeof(image.header.colorMapDepth));
    outputFile.write(reinterpret_cast<char*>(&image.header.xOrigin), sizeof(image.header.xOrigin));
    outputFile.write(reinterpret_cast<char*>(&image.header.yOrigin), sizeof(image.header.yOrigin));
    outputFile.write(reinterpret_cast<char*>(&image.header.width), sizeof(image.header.width));
    outputFile.write(reinterpret_cast<char*>(&image.header.height), sizeof(image.header.height));
    outputFile.write(reinterpret_cast<char*>(&image.header.bitsPerPixel), sizeof(image.header.bitsPerPixel));
    outputFile.write(reinterpret_cast<char*>(&image.header.imageDescriptor), sizeof(image.header.imageDescriptor));


    // Write pixels
    for (int i = 0; i<(image.header.width * image.header.height); i++) {
        Pixel currentPixel = image.pixelData[i];
        unsigned char currentBlue = currentPixel.BLUE;
        unsigned char currentGreen = currentPixel.GREEN;
        unsigned char currentRed = currentPixel.RED;
        outputFile.write(reinterpret_cast<char*>(&currentBlue), sizeof(currentBlue));
        outputFile.write(reinterpret_cast<char*>(&currentGreen), sizeof(currentGreen));
        outputFile.write(reinterpret_cast<char*>(&currentRed), sizeof(currentRed));
    }

    outputFile.close();
}


unsigned char Clamping(int value) {
    // all values lower than zero become zero
    if (value < 0) {
        return 0;
    }
    // all values greater than 255 become 255
    else if (value > 255) {
        return 255;
    }
    return static_cast<unsigned char>(value);
}



// * Algorithms * //
// Multiply
Pixel Multiply(const Pixel& P1, const Pixel& P2) {
    Pixel product;
    int updated_red= (P1.RED / 255.0f) * (P2.RED / 255.0f) * 255 + 0.5f;
    product.RED = Clamping(updated_red);
    int updated_green= (P1.GREEN / 255.0f) * (P2.GREEN / 255.0f) * 255 + 0.5f;
    product.GREEN = Clamping(updated_green);
    int updated_blue= (P1.BLUE / 255.0f) * (P2.BLUE / 255.0f) * 255 + 0.5f;
    product.BLUE = Clamping(updated_blue);
    return product;
}

// Screen
Pixel Screen(const Pixel& P1, const Pixel& P2) {
    Pixel screen_result;
    // RED
    float screenRed = 1 - (1 - (P1.RED / 255.0f)) * (1 - (P2.RED / 255.0f));
    int updated_red = screenRed * 255 + 0.5f;
    screen_result.RED = Clamping(updated_red);

    // GREEN
    float screenGreen = 1 - (1 - (P1.GREEN / 255.0f)) * (1 - (P2.GREEN / 255.0f));
    int updated_green = screenGreen * 255 + 0.5f;
    screen_result.GREEN = Clamping(updated_green);

    // BLUE
    float screenBlue = 1 - (1 - (P1.BLUE / 255.0f)) * (1 - (P2.BLUE / 255.0f));
    int updated_blue = screenBlue * 255 + 0.5f;
    screen_result.BLUE = Clamping(updated_blue);

    return screen_result;
}

// Subtract
Pixel Subtract(const Pixel& P1, const Pixel& P2) {
    Pixel subtracted_result;
    subtracted_result.RED = Clamping(P1.RED - P2.RED);
    subtracted_result.GREEN = Clamping(P1.GREEN - P2.GREEN);
    subtracted_result.BLUE = Clamping(P1.BLUE - P2.BLUE);
    return subtracted_result;
}

// Addition
Pixel Addition(const Pixel& p1, const Pixel& p2) {
    Pixel added_result;
    added_result.RED = Clamping(p1.RED + p2.RED);
    added_result.GREEN = Clamping(p1.GREEN + p2.GREEN);
    added_result.BLUE = Clamping(p1.BLUE + p2.BLUE);
    return added_result;
}

// Overlay
Pixel Overlay(const Pixel& P1, const Pixel& P2) {
    Pixel overlay_result;

    // RED
    float red1_normal = P1.RED / 255.0f;
    float red2_normal = P2.RED / 255.0f;
    int updated_red;

    if (red2_normal <= 0.5f) {
        updated_red = 2 * red1_normal * red2_normal * 255 + 0.5f;
    } else {
        updated_red = (1 - 2 * (1 - red1_normal) * (1 - red2_normal)) * 255 + 0.5f;
    }
    overlay_result.RED = Clamping(updated_red);

    // GREEN
    float green1_normal = P1.GREEN / 255.0f;
    float green2_normal = P2.GREEN / 255.0f;
    int updated_green;

    if (green2_normal <= 0.5f) {
        updated_green = 2 * green1_normal * green2_normal * 255 + 0.5f;
    } else {
        updated_green = (1 - 2 * (1 - green1_normal) * (1 - green2_normal)) * 255 + 0.5f;
    }
    overlay_result.GREEN = Clamping(updated_green);

    // BLUE
    float blue1_normal = P1.BLUE / 255.0f;
    float blue2_normal = P2.BLUE / 255.0f;
    int updated_blue;

    if (blue2_normal <= 0.5f) {
        updated_blue = 2 * blue1_normal * blue2_normal * 255 + 0.5f;
    } else {
        updated_blue = (1 - 2 * (1 - blue1_normal) * (1 - blue2_normal)) * 255 + 0.5f;
    }
    overlay_result.BLUE = Clamping(updated_blue);

    return overlay_result;
}




int main() {
    // * Tasks * //
    // Task 1 Multiply blending mode
    {
        string top_layer = "input/layer1.tga";
        string bottom_layer = "input/pattern1.tga";
        Image read_top = ReadTGA(top_layer);
        Image read_bottom = ReadTGA(bottom_layer);
        Image task1_result;
        task1_result.header = read_top.header;

        // Multiply each pixel
        for (int i = 0; i < read_top.pixelData.size(); ++i) {
            Pixel top_pixel  = read_top.pixelData[i];
            Pixel bottom_pixel = read_bottom.pixelData[i];
            Pixel product_pixel = Multiply(top_pixel, bottom_pixel);
            task1_result.pixelData.push_back(product_pixel);
        }

        string outpath = "output/task1.tga";
        WriteFile(task1_result, outpath);
    }

    // Task 2 Subtract blending mode
    {
        string bottom_layer = "input/layer2.tga";
        string top_layer = "input/car.tga";
        Image read_layer2 = ReadTGA(bottom_layer);
        Image read_car = ReadTGA(top_layer);
        Image task2_result;
        task2_result.header = read_layer2.header;

        // Subtract each pixel
        for (int i = 0; i < read_car.pixelData.size(); ++i) {
            Pixel top_pixel = read_car.pixelData[i];
            Pixel bottom_pixel = read_layer2.pixelData[i];
            Pixel subtracted_pixel = Subtract(top_pixel, bottom_pixel);
            task2_result.pixelData.push_back(subtracted_pixel);
        }
        string outpath = "output/task2.tga";
        WriteFile(task2_result, outpath);
    }

    // Task 3:
    {
        string path1 = "input/layer1.tga";
        string path2 = "input/pattern2.tga";
        string path3 = "input/text.tga";
        Image layer1 = ReadTGA(path1);
        Image pattern2 = ReadTGA(path2);
        Image text = ReadTGA(path3);
        Image blend;
        blend.header = layer1.header;

        // Multiply layer1 and pattern2
        for (int i = 0; i < layer1.pixelData.size(); ++i) {
            Pixel layer1_pixel = layer1.pixelData[i];
            Pixel pattern2_pixel = pattern2.pixelData[i];
            Pixel multiplied_pixel = Multiply(layer1_pixel, pattern2_pixel);
            blend.pixelData.push_back(multiplied_pixel);
        }

        // Screen with text image
        Image task3_result;
        task3_result.header = blend.header;
        for (int i = 0; i < blend.pixelData.size(); ++i) {
            Pixel intermediate_pixel = blend.pixelData[i];
            Pixel text_pixel = text.pixelData[i];
            Pixel screened_pixel = Screen(intermediate_pixel, text_pixel);
            task3_result.pixelData.push_back(screened_pixel);
        }

        string outpath = "output/task3.tga";
        WriteFile(task3_result, outpath);
    }

    // Task 4:
    {
        string path1 = "input/layer2.tga";
        string path2 = "input/circles.tga";
        Image layer2 = ReadTGA(path1);
        Image circles = ReadTGA(path2);
        Image intermediate;
        intermediate.header = layer2.header;

        // Multiply layer2 and circles
        for (int i = 0; i < layer2.pixelData.size(); ++i) {
            Pixel layer2_pixel = layer2.pixelData[i];
            Pixel circles_pixel = circles.pixelData[i];
            Pixel multiplied_pixel = Multiply(layer2_pixel, circles_pixel);
            intermediate.pixelData.push_back(multiplied_pixel);
        }

        // Subtract pattern2
        string path3 = "input/pattern2.tga";
        Image pattern2 = ReadTGA(path3);
        Image task4_result;
        task4_result.header = intermediate.header;
        for (int i = 0; i < intermediate.pixelData.size(); ++i) {
            Pixel intermediate_pixel = intermediate.pixelData[i];
            Pixel pattern2_pixel = pattern2.pixelData[i];
            Pixel subtracted_pixel = Subtract(intermediate_pixel, pattern2_pixel);
            task4_result.pixelData.push_back(subtracted_pixel);
        }

        string outpath = "output/task4.tga";
        WriteFile(task4_result, outpath);
    }

    // Task 5:
    {
        string path1 = "input/layer1.tga";
        string path2 = "input/pattern1.tga";
        Image layer1 = ReadTGA(path1);
        Image pattern1 = ReadTGA(path2);
        Image task5_result;
        task5_result.header = layer1.header;

        // Apply Overlay blending mode
        for (int i = 0; i < layer1.pixelData.size(); ++i) {
            Pixel layer1_pixel = layer1.pixelData[i];
            Pixel pattern1_pixel = pattern1.pixelData[i];
            Pixel overlay_pixel = Overlay(layer1_pixel, pattern1_pixel);
            task5_result.pixelData.push_back(overlay_pixel);
        }

        string outpath = "output/task5.tga";
        WriteFile(task5_result, outpath);
    }


    // Task 6:
    {
        string path = "input/car.tga";
        Image car = ReadTGA(path);

        for (int i = 0; i < car.pixelData.size(); ++i) {
            Pixel& pixel = car.pixelData[i];
            pixel.GREEN = Clamping(pixel.GREEN + 200);
        }

        string outpath = "output/task6.tga";
        WriteFile(car, outpath);
    }

    // Task 7
    {
        string path = "input/car.tga";
        Image car = ReadTGA(path);

        // Scale red channel by 4 and set blue channel to 0
        for (size_t i = 0; i < car.pixelData.size(); ++i) {
            Pixel& pixel = car.pixelData[i];
            pixel.RED = Clamping(pixel.RED * 4);
            pixel.BLUE = 0;
        }

        string outpath = "output/task7.tga";
        WriteFile(car, outpath);
    }


    // Task 8:
    {
        string path = "input/car.tga";
        Image car = ReadTGA(path);

        Image redChannel = car;
        Image greenChannel = car;
        Image blueChannel = car;

        // Separate channels
        for (int i = 0; i < car.pixelData.size(); ++i) {
            Pixel pixel = car.pixelData[i];
            redChannel.pixelData[i] = {pixel.RED, pixel.RED, pixel.RED};
            greenChannel.pixelData[i] = {pixel.GREEN, pixel.GREEN, pixel.GREEN};
            blueChannel.pixelData[i] = {pixel.BLUE, pixel.BLUE, pixel.BLUE};
        }

        WriteFile(redChannel, "output/task8_r.tga");
        WriteFile(greenChannel, "output/task8_g.tga");
        WriteFile(blueChannel, "output/task8_b.tga");
    }


    // Task 9:
    {
        string pathR = "input/layer_red.tga";
        string pathG = "input/layer_green.tga";
        string pathB = "input/layer_blue.tga";
        Image red_layer = ReadTGA(pathR);
        Image green_layer = ReadTGA(pathG);
        Image blue_layer = ReadTGA(pathB);

        Image task9_result;
        task9_result.header = red_layer.header;

        // Combine
        for (int i = 0; i < red_layer.pixelData.size(); ++i) {
            Pixel combined_pixel;
            combined_pixel.RED = red_layer.pixelData[i].RED;
            combined_pixel.GREEN = green_layer.pixelData[i].GREEN;
            combined_pixel.BLUE = blue_layer.pixelData[i].BLUE;
            task9_result.pixelData.push_back(combined_pixel);
        }

        string outpath = "output/task9.tga";
        WriteFile(task9_result, outpath);
    }


    // Task 10:
    {
        string path = "input/text2.tga";
        Image text2 = ReadTGA(path);
        Image task10_result;
        task10_result.header = text2.header;

        // Rotate by reversing the pixel data order
        for (int i = text2.pixelData.size() - 1; i >= 0; --i) {
            Pixel current_pixel = text2.pixelData[i];
            task10_result.pixelData.push_back(current_pixel);
        }

        string outpath = "output/task10.tga";
        WriteFile(task10_result, outpath);
    }

    //cout << "done" << endl;
    return 0;
}
